Note that freeglut, glee and libpng need to be installed.

Unfortunately, we can only provide limited support for running this
exercise on Linux.
